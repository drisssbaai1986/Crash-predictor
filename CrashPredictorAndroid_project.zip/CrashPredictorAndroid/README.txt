Crash Predictor — Android project source

مهم:
- هذا التطبيق محلل إحصائي يدوي للنتائج السابقة فقط.
- لا يتصل بـ 1xBet، ولا يتجاوز أنظمة الحماية، ولا يتنبأ بنتيجة الجولة القادمة.
- لا تدخل كلمة المرور أو بيانات حسابك في أي أداة خارجية.

لإنشاء APK:
1) افتح المشروع في Android Studio.
2) انتظر مزامنة Gradle.
3) اختر Build > Build Bundle(s) / APK(s) > Build APK(s).
4) ستجد APK داخل app/build/outputs/apk/debug/.

هذا أرشيف مشروع قابل للبناء، وليس ملف APK جاهزاً. يتطلب إنشاء APK تثبيت Android Studio وAndroid SDK.
